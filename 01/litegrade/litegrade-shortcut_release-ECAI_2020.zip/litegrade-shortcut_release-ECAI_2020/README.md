# litegrade

A Python module that can be used to ask questions and provide real-time feedback of the answers
