from setuptools import setup

setup(
	name='unittesting',
	version='0.1',
	description='A assert style unit testing toolset',
	author='Justin Morgan',
	author_email='jmorga27@calpoly.edu',
	packages=['/home/jmorga27/Cal_Poly/Kurfess/litegrade/test/unittesting'],
	install_requires=[],
)
